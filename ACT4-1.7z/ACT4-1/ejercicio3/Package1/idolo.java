package Package1;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class idolo {

    /**
     * Default constructor
     */
    public idolo() {
    }

    /**
     * 
     */
    public String nombre;

}