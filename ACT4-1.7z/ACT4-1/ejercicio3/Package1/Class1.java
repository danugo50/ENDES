package Package1;

import java.io.*;
import java.util.*;

/**
 * 
 */
public class Class1 {

    /**
     * Default constructor
     */
    public Class1() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String color;

    /**
     * 
     */
    public boolean aptoPilotar;

    /**
     * @param x 
     * @param y 
     * @return
     */
    public float solucionarEcuacion(float x, float y) {
        // TODO implement here
        return 0.0f;
    }

}